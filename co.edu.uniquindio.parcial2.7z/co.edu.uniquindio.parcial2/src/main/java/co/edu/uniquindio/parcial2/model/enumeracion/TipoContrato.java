package co.edu.uniquindio.parcial2.model.enumeracion;

public enum TipoContrato {
    HORAS, MEDIO_TIEMPO, TIEMPO_COMPLETO
}
