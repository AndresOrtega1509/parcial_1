package co.edu.uniquindio.parcial2.model;

public class Administrador extends Empleado {

    /*Constructor*/

    public Administrador() {
    }
}