package co.edu.uniquindio.parcial1.ejercicio2;
import co.edu.uniquindio.parcial1.model.Automovil;
import co.edu.uniquindio.parcial1.model.Empleado;

public class MainEjercicio2 {
    public static void main(String[] args) {

        Automovil automovil1 = new Automovil("Chevrolet", "4 puertas", "Electrico", 5, 30.000);
        Automovil automovil2 = new Automovil("Mercedes", "5 puertas", "Electrico", 8, 40.000);
        Automovil automovil3 = new Automovil("Susuki", "2 puertas", "Gasolina", 4, 25.000);
        Automovil automovil4 = new Automovil("Camaro", "4 puertas", "Hibrido", 7, 60.000);
        Empleado empleado1 = new Empleado("Juan", "Mendez", "1083647382", "Administrativo", "gerente", 800.000);
        Empleado empleado2 = new Empleado("Sofia", "Ortega", "23344674", "Ventas", "coordinador", 600.000);
        Empleado empleado3 = new Empleado("Sofia", "Ortega", "23344674", "Ventas", "coordinador", 600.000);


    }
}
