package co.edu.uniquindio.parcial2.model;

public class Recolector extends Empleado{

    /*Constructor*/

    public Recolector() {
    }
}