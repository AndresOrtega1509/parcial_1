package co.edu.uniquindio.parcial1.ejercicio3;

public class MainEjercicio3 {
}
