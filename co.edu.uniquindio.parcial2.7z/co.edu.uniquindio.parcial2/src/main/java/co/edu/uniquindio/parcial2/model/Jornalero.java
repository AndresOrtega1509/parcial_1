package co.edu.uniquindio.parcial2.model;

public class Jornalero extends Empleado{

    /*Constructor*/
    public Jornalero() {
    }

}
